# Quiz game README & Legend

This is a simple quizgame written in python. You can use this to host several different quizes.






# Markdown Example
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.